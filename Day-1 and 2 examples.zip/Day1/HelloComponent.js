import React from "react";

class HelloComponent extends React.Component
{
    render()
    {
        return <h2>another class component</h2>
    }
}

export default HelloComponent