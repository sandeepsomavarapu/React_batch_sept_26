import { useState } from "react";

export function useCounter(intialvalue=0){
    const [count,setCount]=useState(intialvalue)

    const increment=()=>setCount(prev=>prev+1)
     const decrement=()=>setCount(prev=>prev-1)
     const reset=()=>setCount(intialvalue)

     return {count,increment,decrement,reset}

}