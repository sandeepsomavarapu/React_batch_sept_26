import React from "react";

class EmployeeComponent extends React.Component
{
    constructor(props)
    {
        super()
        this.state={eid:123,ename:'suresh',esal:23000}
    }

    render()
    {
        return(
            <div>
            <p>Employee Info  {this.props.orgname}</p>
            <p>Id    :{this.state.eid}</p>
            <p>Name  :{this.state.ename}</p>
            <p>Salary:{this.state.esal}</p>
            </div>
        )
    }
}
export default EmployeeComponent