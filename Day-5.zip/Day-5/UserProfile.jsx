import React, { Component } from 'react'
import withRouter from './withRouter'

const mockUsers={
    1:{name:"suresh",role:"admin"},
    2:{name:"ramesh",role:"hr"},
    3:{name:"naresh",role:"developer"},

}
class UserProfile extends Component {
  render() {
    const {id}=this.props.params
    const user =mockUsers[id]
    if(!user){
        return <h2>USER Not Found !!!</h2>
    }
    return (
      <div>
        <h2>User Profile (ID:{id})</h2>
            <p>{user.name}</p>
             <p>{user.role}</p>
      </div>
    )
  }
}
export default withRouter(UserProfile)