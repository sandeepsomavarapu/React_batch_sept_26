import React, { Component } from 'react'

export default class LoginControlledForm extends Component {
    constructor(props) {
        super(props)

        this.state = {
                username:'',
                password:'',
                errors:{},
                isSubmitted:false
        }
    }
    handleChange=(event)=>{
            const{name,value}=event.target
            this.setState({
                [name]:value
            },()=>this.validateField(name,value)
        )
    }

    validateField=(fieldname,value)=>{
        let error=""
        switch (fieldname) {
           case 'username':
                if(!value.trim()) error="Username is required"
                else if (value.length<3) error="Username must have min 3 chars"
                 break;
            case 'password':
                if(!value.trim()) error="Password is required"
                else if (value.length<3) error="Password must have min 3 chars"
                 break;     
            default:
                break;
        }
        this.setState((prevState)=>({
            errors:{...prevState.errors,[fieldname]:error}

        }))
    }
    handleSubmit=(event)=>{
        event.preventDefault()
        const {username,password}=this.state;
        console.log("Credentials",{username,password})
        alert(username+" "+password)
    }
    render() {
        const {username,password,errors,isSubmitted}=this.state
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <h2>Login (Controlled)Form</h2>
                    <input type="text" name="username" value={username} onChange={this.handleChange}></input><br/><br/>
                    {errors.username && <span style={{color:"red"}}>{errors.username}</span>}
                    <input type="password" name="password" value={password} onChange={this.handleChange}></input><br/><br/>
                    {errors.password && <span style={{color:"red"}}>{errors.password}</span>}
                    <button type="submit">LOGIN</button>
                </form>
            </div>
        )
    }
}
