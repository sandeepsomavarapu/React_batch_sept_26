import React, { useState } from 'react'

const UseStateHoonkDemo3 = () => {
    const [todos, setTodos] = useState(['Leanr React Routing', 'Master useState'])
    const [inputValue, setInputValue] = useState("")

    const handleAddTodo = () => {
        if (!inputValue.trim()) return;
        setTodos([...todos, inputValue])
        setInputValue('')
    }

    const handleDelete = (indexToDelete) => {
        setTodos(todos.filter((_, index) => index !==indexToDelete))

    }
    return (
        <div>
            <div>
            <input type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)}></input>
            <button onClick={handleAddTodo}>Add Task </button>
            </div>
            <ul>
            {todos.map((todo, index) => (
                <li key={index}>
                    {todo}{''}
                    <button onClick={() => handleDelete(index)}> Delete</button>
                </li>
            )
            )}
            </ul>
        </div>
    )
}

export default UseStateHoonkDemo3
