const numbers=[10,20,30]
const first=numbers[0]
const second=numbers[1]
const third=numbers[2]

console.log(first)
console.log(second)
console.log(third)

//ES6
const numbers1=[10,20,30]

const[a,b,c]=numbers1
console.log(a)
console.log(b)
console.log(c)

const student={
name:"ramesh",
age:"33",
city:"hyderabad"
}
const name=student.name
const age=student.age
const city=student.city
console.log(name)

const{name1,age1,city1}=student
console.log(name1)
console.log(age1)


