import React, { useState } from 'react'

const UseStateHookDemo = () => {
          const[count,setCount]=useState(0);

          const handleIncrement=()=>{
            setCount((prevCount)=>prevCount+1)
          }

           const handleDecrement=()=>{
            setCount((prevCount)=>prevCount>0?prevCount-1:0)
          }
          const handleReset=()=>{
            setCount(0)
          }
  return (
    <div>
        <h2>Counter App</h2>
        <h1>{count}</h1>
        <button onClick={handleDecrement}>Decrement</button>
         <button onClick={handleIncrement}>Increment</button>
          <button onClick={handleReset}>Reset</button>
      
    </div>
  )
}

export default UseStateHookDemo
