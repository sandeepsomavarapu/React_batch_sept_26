import React from 'react'
const Home = () => {
  return (
    <div>
      <h2>Home Page-Welcome to our site!!</h2>
    </div>
  )
}
export default Home
