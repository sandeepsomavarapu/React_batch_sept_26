import React from "react"
class ClassComponent extends React.Component
{
    render()
    {
        return(
        <div>
            <h2>from class component</h2>
        </div>
        )
    }

}
export default ClassComponent