let age=33//global scope
    {
        let age=34//block level scope
       
        console.log(age)
    }
 console.log(age)   

const square=a => a*a ;

console.log(square(2))

function add(a,b){
    var result=a+b
    return result
}
