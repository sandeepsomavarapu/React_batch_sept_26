import React, { Children, createContext, useState } from 'react'

//1.create context

export const UserContext=createContext()

//2.create provider component
export const  UserProvider=({children})=>{
    const [user,setUser]=useState({name:'suresh',isLoggedIn:true})

    const logout=()=>{
        setUser({name:'',isLoggedIn:false})
    }
    return(
        <UserContext.Provider value={{user,logout}}>
            {children}
        </UserContext.Provider>
    )
}
