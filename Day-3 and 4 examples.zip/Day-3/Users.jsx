import React, { Component } from 'react'
import Button from './Button'

export default class Users extends Component {

    constructor(props) {
        super(props)
        this.state = {
            users: [
                { id: 123, name: "suresh", address: "hyderabad" },
                { id: 124, name: "ramesh", address: "delhi" },
                { id: 125, name: "rajesh", address: "banglore" },
                { id: 126, name: "naresh", address: "delhi" },
                { id: 127, name: "kumar", address: "banglore" },

            ]
        }  
    }
    deleteUser=(id)=>{
       const updatedUsers=this.state.users.filter((user)=>user.id!=id)
       console.log(updatedUsers)
       this.setState({users:updatedUsers})
    }
    render() {
        return (
            <div>
                <table className='table table-hover table-dark'>
                    <thead>
                    <tr>
                        <th>UserId</th>
                        <th>UserName</th>
                        <th>UserAddress</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    {
                        this.state.users.map((user) => (
                            <tbody  key={user.id}>
                            <tr>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                                <td>{user.address}</td>
                                <td><button className='btn btn-primary' onClick={()=>this.deleteUser(user.id)} type="button">DELETE </button></td>
                            </tr>
                            </tbody>
                        ))}
                </table>
                <Button text="LOGIN"/>
                <Button text="Register"/>
                <Button text="ContactUs"/>
            </div>
        )
    }
}
