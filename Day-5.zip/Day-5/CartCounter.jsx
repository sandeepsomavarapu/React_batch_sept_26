import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
const CartCounter = () => {
    const cartCount = useSelector((state) => state.cartCount);
    const dispatch = useDispatch();
    return (
        <div>
            Cart Count: {cartCount}
            <button onClick={() => dispatch({ type: "ADD_TO_CART" })}>Add to Cart</button>
            <button onClick={() => dispatch({ type: "REMOVE_FROM_CART" })}>Remove from Cart</button>
        </div>
    )
}
export default CartCounter
