import React, { Component } from 'react'

export default class Child extends Component {

constructor(props) {
  super(props)

  this.state = {
     
  }
}

    sendData=()=>{
        this.props.onSend("Hello from child")
    }
  render() {
    return (
      <div>
        <button onClick={this.sendData}>Click Me </button>
      </div>
    )
  }
}
