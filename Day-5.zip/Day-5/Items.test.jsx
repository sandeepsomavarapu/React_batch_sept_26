import {Items} from './Items';

describe('Items component', () => {
  test('should call the callback function for each item', () => {
    const items = ['item1', 'item2', 'item3'];
    const mockcallback = jest.fn();
    // jest.mock("axios")

    Items(items, mockcallback);

    expect(mockcallback).toHaveBeenCalledTimes(3);
    expect(mockcallback).toHaveBeenCalledWith('item1');
    expect(mockcallback).toHaveBeenCalledWith('item2');
    expect(mockcallback).toHaveBeenCalledWith('item3');
  });
});
