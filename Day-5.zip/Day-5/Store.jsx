// store.js
import { createStore } from "redux";

const initialState = {
  cartCount: 0,
};

function cartReducer(state = initialState, action) {
  switch (action.type) {
    case "ADD_TO_CART":
      return {
        ...state,
        cartCount: state.cartCount + 1,
      };
    case "REMOVE_FROM_CART":
      return {
        ...state,
        cartCount: state.cartCount - 1,
      };  
    default:
      return state;
  }
}

const store = createStore(cartReducer);

export default store;