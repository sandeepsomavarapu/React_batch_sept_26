class Student{

    constructor(name,age){
        this.name=name
        this.age=age    }

    display(){
        console.log(this.name,this,age)
    }

}const obj=new Student("kiran",23)
obj.display()

class Section extends ClassTest{
    
}