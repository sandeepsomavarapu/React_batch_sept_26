import React, { Component } from 'react'
class LoginForm extends React.Component
{
    constructor(props) {
      super(props)    
      this.state = {
         username:"",
         password:"",
         message:"",
         isLoggedIn:false
      }
    }
    handleChange=(event)=>{
        console.log(event.target.name,event.target.value)
            this.setState({
                    [event.target.name]:event.target.value
            })
    }
     handleSubmit=(event)=>{
        event.preventDefault()
        const{username,password}=this.state
        if(username==="admin" && password==="admin123")
        {
            this.setState({
                message:"LOGIN SUCCESS",
                isLoggedIn:true
            })

        }
        else{
            this.setState({message:"INVALID CREDENTIALS"})
        }
    }
    render()
    {
        return (
                <div>
                    {this.state.isLoggedIn ? <h1>Welcome back!</h1> :  <h2>LOGIN HERE</h2>}
                   
                <form onSubmit={this.handleSubmit}>
                      Username:<input type="text" name="username" value={this.state.username} onChange={this.handleChange}></input>  <br></br>
                      Password: <input type="password" name="password" value={this.state.password} onChange={this.handleChange}></input><br></br>  
                      <input type="submit" value="LOGIN"></input>  
                    {this.state.message && <p>{this.state.message}</p>}
                    {!this.state.result && <p style={{color:"red"}}>Invalid Credentials</p>}
                     {this.state.result && <p style={{color:"green"}}>Valid credentiils</p>}
                </form>
                </div>
        )
    }
}
export default LoginForm