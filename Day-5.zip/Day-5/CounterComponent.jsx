import { useCounter } from "./useCounter";



function CounterComponent() {

    const { count, increment, decrement, reset } = useCounter(10)
    return (
        <div>
            <h3>Count :{count}</h3>
            <button onClick={increment}>+1</button>
            <button onClick={decrement}>-1</button>
            <button onClick={reset}>Reset</button>
        </div>
    )
}
export default CounterComponent