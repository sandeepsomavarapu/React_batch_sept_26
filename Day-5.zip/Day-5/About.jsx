import React from 'react'

const About = () => {
  return (
    <div>
        <h2>About Page --Learn More about us</h2>
    </div>
  )
}

export default About
