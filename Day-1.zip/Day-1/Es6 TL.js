function m1()
{

}
let name1="sandeep"
let age=33

let message="my  name is "+name1+" and  my age is "+age
console.log(message)


let message1=`my  name is ${name1} and  my age is ${age}`
console.log(message1)

let a=23
let b=33
console.log(`Total=${a=>a*a}`)

let multiline="Hello \n"+
                "welcome to india \n"+
                "welcome to hyderabad";
let multiline1=`
hello
welcome
india
`           
print()     