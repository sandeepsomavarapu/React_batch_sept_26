function WelcomeComponent(){
    return <h2>am from welcome component </h2>
}
export default WelcomeComponent