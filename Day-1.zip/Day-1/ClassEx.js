function Student(name,age){
    this.name=name
    this.age=age
}
Student.prototype.display=function(){
    console.log(this.name,this.age)
}

const s1=new Student("ramesh",26)
s1.display()