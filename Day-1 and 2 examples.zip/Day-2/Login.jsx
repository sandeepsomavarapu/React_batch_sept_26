import React from 'react'
import Counter from './Counter'
export default class Login extends React.Component
{
    constructor(props) {
      super(props)
      this.state = {
         
      }
    }
    
    render()
    {
       return <> 
       <h1>In Login {this.props.message}</h1> 
       <Counter data={this.props.message}></Counter>
       </>
    }
}
