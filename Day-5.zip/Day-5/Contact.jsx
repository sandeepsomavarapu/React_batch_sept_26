import React from 'react'

const Contact = () => {
  return (
    <div>
      <h2>Contact Page-- Get in touch with us ..</h2>
    </div>
  )
}

export default Contact
