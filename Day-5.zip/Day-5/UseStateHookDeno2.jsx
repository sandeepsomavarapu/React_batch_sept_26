import React, { useState } from 'react'

const UseStateHookDeno2 = () => {
    const [isVisible,setIsVisible]=useState(false)
    const toggleVisibility=()=>{
        setIsVisible((prev)=>!prev)
    }
  return (
    <div>
      <button  onClick={toggleVisibility}>{isVisible?"HideDetails":"Show Details"}</button>
    
    {isVisible && (<div> 
        <p>This Paragraph is dynamically shown or hidden on  'useState'</p>
         </div>)}



    </div>

  )
}

export default UseStateHookDeno2
