const a=[10,20]
const b=[30,40]
const result=a.concat(b)
console.log(result)
const result1=[...a,...b,90,23]
console.log(result1)
const student ={
    name:"rajesh",
    age:25
}

const updatedStudent={
    ...student,marks:90

}
console.log(updatedStudent)

//Spread-->expands
//Rest-->collects

const numbers=[10,20,30,40]
const [first,...remaining]=numbers

function greet(name="SURESH"){
    console.log(`Hello ${name}`)
}
greet()