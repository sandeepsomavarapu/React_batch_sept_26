

function functionalcomponent(props){
        // {props.name="suresh"}
        return <h1>am from functional component  {props.name}</h1>
}
export default functionalcomponent;