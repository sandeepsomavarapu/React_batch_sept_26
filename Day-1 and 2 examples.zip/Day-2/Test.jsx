import React from "react";
class Test extends React.Component {
    constructor(props) {
        console.log("constructor....")
        super(props);
        this.state = { hello: "World!" };
    }

    componentDidMount() {
        console.log("componentDidMount()");
    }

    changeState = () => {
        this.setState({ hello: "User!" });
    };

    shouldComponentUpdate(nextProps, nextState) {
        console.log("shouldComponentUpdate()");
        return true;
    }

    componentDidUpdate() {
        console.log("componentDidUpdate()");
    }
    componentWillUnmount() {
        console.log("component will unmount:cleanup")

    }
    render() {
        console.log("render...")
        return (
            <div>
                <h1>
                    Hello {this.state.hello}
                </h1>
                <h2>
                    <button onClick={this.changeState}>
                        Press Here!
                    </button>
                </h2>
            </div>
        );
    }
}
export default Test;