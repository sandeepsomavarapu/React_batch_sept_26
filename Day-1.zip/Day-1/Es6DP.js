function add(a, b=23) {
    let result = a + b
    return result;
}
console.log(add(10,20))
console.log(add(10))