import React, { Component } from 'react'

export default class Button extends Component {
  render(props) {
    return (
      <div>
        <button type="button">{this.props.text}</button>
      </div>
    )
  }
}
