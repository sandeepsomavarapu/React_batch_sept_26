import React, { Component } from 'react'
export default class Counter extends Component {
    constructor(props) {
      super(props)
      this.state = {
         count:0,
         appname:props.data
      }
      //explicit binding of this
      this.increment2=this.increment2.bind(this)
      this.handleClick=this.handleClick.bind(this)
    }
    increment2() {
        this.setState({count:this.state.count+2});
    }
    increment=()=>{
        this.setState({count:this.state.count+1});
    };
    decrement=()=>{
        this.setState({count:this.state.count-1});
    };
    updateAppName=()=>{
      this.setState({appname:"AMAZON"})
    }
    handleClick(e){
      console.log("Button Id",e.target.id)
      console.log("Button Tag Name",e.target.tagName)
      alert(`you clicked ${e.target.innerText}`)
    }
  render() {
    return (
      <div>
        <p>{this.props.data}</p>
         <p>{this.state.appname}</p>
         <button onClick={this.updateAppName}>update name</button>
        <p>count value :{this.state.count}</p>
        <button onClick={this.increment}>INCREMENT</button>
        <button onClick={this.decrement}>DECREMENT</button>
        <button onClick={this.increment2}>+2</button>
        <button id="btn-1" onClick={this.handleClick}>Click Me</button>
      </div>
    )
  }
}
