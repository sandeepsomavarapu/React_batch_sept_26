import React, { Component } from 'react'

export default class UserProfile extends Component {
  constructor(props) {
    super(props)

    this.state = {
       user:null,
       loading:true,
       secondsActive:0
    }
    this.timerId=null;
    console.log("1.Constructor Intialized")
  }
  //Mounting Phase
  componentDidMount(){
    console.log("3.componentdidmount:rendered on screen")
    //api call
    this.timerId=setInterval(()=>{
        this.setState((prevState)=>({secondsActive:prevState.secondsActive+1}));
    },1000)
  }
  //updating phase
  componentWillUnmount(){
    console.log("component will unmount:cleanup")
    if(this.timerId){
        clearInterval(this.timerId)
    }
  }

  render() {
    console.log("2.render computing UI JSX")
    return (
      <div>
        <h1>User Profile</h1>
      </div>
    )
  }
}
