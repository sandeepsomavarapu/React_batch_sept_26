import React, { Component } from 'react'

export default class RegistrationUncontrolledForm extends Component {

    constructor(props) {
        super(props)
        this.usernameRef = React.createRef();
        this.emailRef = React.createRef();
        this.passwordRef = React.createRef();
        this.ageRef = React.createRef();
        this.roleRef = React.createRef();
        this.bioRef = React.createRef();

        this.state = {
            errors: {},
            isSubmitted: false
        }

    }

    handleBlur=(ref,fieldName)=>{
            const value=ref.current.value;
            let error='';
            switch(fieldName){
                case 'username':
                    if(!value.trim()) error="Username is required"
                    else if (value.length<3) error="Username must have min 3 chars"
                    break;
                case 'email':
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                    if(!value.trim()) error="Email is required"
                    else if (!emailRegex.test(value)) error="Invalid Email..."    
                    break;
                case 'password':
                    if(!value) error="Password is required"
                    else if(value.length<6) error ="Password must be min 6 chars..."
                    break;
                default :
                 break    
            }
            this.setState((prevState)=>({
                errors:{...prevState.errors,[fieldName]:error}
            }))
    }
    handleSubmit = (event) => {
        event.preventDefault()
        const userData = {
            username: this.usernameRef.current.value,
            password: this.passwordRef.current.value,
            email: this.emailRef.current.value,
            age: this.ageRef.current.value,
            role: this.roleRef.current.value,
            bio: this.bioRef.current.value
        }
        console.log("Uncontrolled Registration submit :", userData)
        alert(userData)
    }

    render() {
        const {errors,isSubmitted}=this.state
        return (
            <div>
                <form onSubmit={this.handleSubmit} >
                    <h2>Registration (UnControlled)Form</h2>
                    Username:   <input type="text" ref={this.usernameRef} defaultValue="" onBlur={()=>this.handleBlur(this.usernameRef,'username')}></input>
                    {errors.username && <span style={{color:'red'}}>{errors.username}</span>}
                    <br /><br />
                    Email   :<input type="email" ref={this.emailRef} defaultValue="" onBlur={()=>this.handleBlur(this.emailRef,'email')}></input><br /><br />
                    {errors.email && <span style={{color:'red'}}>{errors.email}</span>}
                    Password:<input type="password" ref={this.passwordRef} defaultValue="" onBlur={()=>this.handleBlur(this.passwordRef,'password')}></input><br /><br />
                       {errors.password && <span style={{color:'red'}}>{errors.password}</span>}
                    Age     :<input type="number" ref={this.ageRef} defaultValue=""></input><br /><br />
                    Role    :<select ref={this.roleRef} defaultValue="">
                                <option value="">Select a Role</option>
                                <option value="Developer">Developer</option>
                                <option value="Designer">Designer</option>
                                <option value="Manager">Manager</option>
                                <option value="HR">HR</option>
                              </select><br /><br />
                    BIO     :<textarea   ref={this.bioRef} defaultValue="" rows="3" ></textarea>          

                    <button type="submit">Register</button>
                </form>
            </div>
        )
    }
}
