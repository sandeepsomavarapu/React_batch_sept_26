import React, { useState } from 'react'

const UseStateHookDemo1 = () => {
        const [name,setName]=useState("")
        const handleChange=(e)=>{
            setName(e.target.value)
        }
        const handleClear=()=>{
            setName("")
        }

  return (
    <div>
        <h2>Text Input Field</h2>
        <input type="text" value={name} onChange={handleChange}></input>
        <button onClick={handleClear}>CLear</button>
        <h3>Hello,{name?name:'Guest User'}</h3>
    </div>
  )
}

export default UseStateHookDemo1
