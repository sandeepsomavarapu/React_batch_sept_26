import React, { useEffect, useState } from 'react';
import { createSlice, createAsyncThunk, configureStore } from '@reduxjs/toolkit';
import { Provider, useSelector, useDispatch } from 'react-redux';

// 1. ASYNC THUNKS (API Calls)
export const fetchPosts = createAsyncThunk('posts/fetchPosts', async () => {
  const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=5');
  return res.json();
});

export const addPost = createAsyncThunk('posts/addPost', async (newPost) => {
  const res = await fetch('https://jsonplaceholder.typicode.com/posts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newPost)
  });
  return res.jso
});

// 2. REDUX SLICE
const postsSlice = createSlice({
  name: 'posts',
  initialState: { items: [], status: 'idle', error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPosts.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload;
      })
      .addCase(fetchPosts.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(addPost.fulfilled, (state, action) => {
        state.items.push(action.payload);
      });
  }
});

// 3. REDUX STORE
const store = configureStore({
  reducer: {
    posts: postsSlice.reducer,
  },
});

// 4. UI COMPONENT
const PostsList = () => {
  const dispatch = useDispatch();
  const { items, status, error } = useSelector((state) => state.posts);
  const [title, setTitle] = useState('');

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchPosts());
    }
  }, [status, dispatch]);

  const handleAddPost = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    dispatch(addPost({ title, body: 'Sample content' }));
    setTitle('');
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Posts List (Redux Toolkit Thunk)</h2>

      <form onSubmit={handleAddPost} style={{ marginBottom: '20px' }}>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter new post title..."
          style={{ padding: '8px', marginRight: '10px', width: '250px' }}
        />
        <button type="submit" style={{ padding: '8px 16px' }}>Add Post</button>
      </form>

      {status === 'loading' && <p>Loading posts...</p>}
      {status === 'failed' && <p style={{ color: 'red' }}>Error: {error}</p>}

      <ul>
        {items.map((post) => (
          <li key={post.id} style={{ marginBottom: '8px' }}>
            {post.title}
          </li>
        ))}
      </ul>
    </div>
  );
};

// 5. EXPORT WRAPPER WITH PROVIDER
export default function PostsApp() {
  return (
    <Provider store={store}>
      <PostsList />
    </Provider>
  );
}